<?php
    session_start();
    require_once ('admin/connection.php');
    $id2 = $_SESSION['id']??'';
    $id = $_GET['id']?? $id2;
    $userName = $_SESSION['userName'] ?? 'zasdnjakens1231ascax';
    if($id !='') {
        $_SESSION['id']=$id;
        $sql = 'select *from apps where id ='.$id;
        $app = $conn->query($sql);
        $app= $app->fetch_assoc();

        $sql = 'select *from comments where appId = '.$id;
        $comments = $conn->query($sql);
        $arr= array();
        while($mt = $comments->fetch_assoc()) {
            $arr[] = $mt;
        }
        $sql = 'select count(*) as count from favorite where appId = ? and userName = ?';
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $id, $userName);
        $stmt->execute();
        $stmt = $stmt->get_result();
        $count = $stmt->fetch_assoc();
        $_SESSION['pageData'] = json_encode(array('comment'=>$arr, 'app'=> $app, 'count'=>$count));
      }
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="app.css">
    <title>Apps</title>
    <script src="app.js"></script>

</head>
<body style="overflow-x: hidden;">

    <nav class="navbar navbar-expand-sm" style="box-shadow: 0px 1px 2px #ccc">
        <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="images/logo2.png" alt="Logo" style="width:100px;">
        </a>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav me-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Box App</a>
            </li>
            </ul>

            <div class="searchBox">
                <span id="searchIcon"><i class="fa fa-search"></i></span>
                <input type="search" id="search" placeholder="Search..." />
            </div>

            <a class="nav-link" href="<?php
            if(!isset($_SESSION['userName'])){
                $_SESSION['currPage'] = 'index.php';
                echo 'loginForm.php'; 
            }
            else {
                echo 'admin/logout.php?currPage=index.php';
            }
            ?>">
            <?php
            if(!isset($_SESSION['userName']))
                echo 'Login';
            else {
                echo $_SESSION['userName'];
            }
            ?>
            </a>
            <a class="navbar-brand" href="./appManagerment.php" style = "margin-left:1%">
                <img src="images/defaultAvatar.png" id = "userImg" alt="User" style="width:40px;" class="rounded-pill"> 
            </a>
        </div>
        </div>
    </nav>

    <div id = "topBar" class = "holder">
        <img id = "icon" src="appContainer/images/gms/tft.jpg" alt="app name">
        <div id = "appName">
            TFT
        </div>

        <div id = "creatorName">
            <a href = "javascript:void()">
                Riot Games, Inc
            </a>
        </div>

        <div id = "dlsBox">
            <div id = "appDownload">
                1.000.00+
            </div>
            <i class="material-icons" style = "color:black;font-size:20px;">file_download</i>
            <div id = "appSize">
                200MB 
            </div>
            <i class="material-icons" style = "color:black;font-size:20px;">&#xe2c7;</i>
            
        </div>
        <div id = "marks">
            <a href = "javascript:void(0)" class = "far" id = "wishlist" onclick="change(1)" >&#xf004;</a>
            <a href = "javascript:void(0)" class = "far" id = "favorite" onclick="change(2)" >&#xf02e;</a>
        </div>
        <button id = "download">
            Download
        </button>
        <div id = "rateBox">
            <?php
                $starNum = 4;
                $totalStar = 5;
                for ($i = 1; $i <= $starNum;$i++){
                    echo "<i class = 'fas rate'> &#xf005; </i>";
                    $totalStar = $totalStar- 1;
                }
                for ($i = 1; $i <= $totalStar;$i++){
                    echo "<i class = 'far rate'> &#xf005; </i>";
                }
            ?>
        </div>
        <div id = "reportBox">
            <a href = "javascript:void(0)" class = "fas" id = "report">&#xf071;</a>
        </div>
    </div>

    <div id = "mainInfo" class = "holder">
        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div style="background-image: url('./images/tft.jpg');" class="carousel-item active">
                </div>
                <div style="background-image: url('./images/pubg.jpg');" class="carousel-item">
                </div>
                <div style="background-image: url('./images/fo4.jpg');" class="carousel-item">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
        
        <div id = "appInfo">
            <div id = "buttonTab">
                <button id = "btn1" class = "subButtonTab" onclick="infoBtnClick(this)">About</button>
                <button id = "btn2" class = "subButtonTab" onclick="infoBtnClick(this)">Updates</button>
                <button id = "btn3" class = "subButtonTab" onclick="infoBtnClick(this)">Extras</button>
            </div>
            <div id = "info">
                <div id = "aboutApp" class = "subInfoTab";>
                    <p id = "text"> Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.Safety starts with understanding how developers collect and share your data. Data privac
                        y and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                        Safety starts with understanding how developers collect and share your data.
                         Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                         Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                         y and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                        Safety starts with understanding how developers collect and share your data.
                         Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                         Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                         y and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                        Safety starts with understanding how developers collect and share your data.
                         Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                         Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                    </p>
                </div>
                <div id = "updates" class = "subInfoTab";>
                    <p id = "text"> Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                    Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                    Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                 </p>
                </div>
                <div id = "moreInfo" class = "subInfoTab";>
                    <p id = "text"> Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                    Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                    Safety starts with understanding how developers collect and share your data. Data privacy and security practices may vary based on your use, region, and age. The developer provided this information and may update it over time.
                 </p>
                </div>
            </div>
        </div>
    </div>
    
    <div id = "moreApps" class = "holder">
        
        <div id = "btnHolder">
            <button id = "moreBtn"> More </button>
            <button onclick ="scrollDiv(this,'right')" class = "fas rightarrow arrow" style = "margin-right: 20px;">&#xf105;</button>
            <button onclick ="scrollDiv(this,'left')" class = "fas leftarrow arrow" >&#xf104;</button>
        </div>
        <div id = "appBasket">
            <?php
                for($i = 0;$i <= 20;$i++){
                    echo "<a href='javascript:void(0)' class='app-type__game--containt app-containt col-4'>";
                    echo "<div class='game-containt__img img-color'></div>";
                    echo "<div class='infor'>";
                    echo "<div class='main-img'><img src='images/empty.png' width='56' height='56' border-radius='4'></image></div>";
                    echo "<div class='infor-text'>";
                    echo "<h5 class='game-containt__name'>Test 1</h5>";
                    echo "<span class='game-containt__username'>Test 2</span>";
                    echo "</div>";
                    echo "</div>";
                    echo "</a>";
                }
            ?>
        </div>
    </div>

    <div id = "commentSection" class = "holder">
        <div id = "ratingContainer">
            <div id = "userRateBox">
                <p id = "text">Your Rating:</p>
                <?php
                    for($i = 1; $i <= 5;$i ++){
                        echo "<a href = 'javascript:void(0)' class = 'far rate' id = '".$i."' onmouseover='changeStarCl(this,1)' onmouseout='changeStarCl(this,2)' onclick='changeStarCl(this,3)'> &#xf005; </a>";
                    }
                ?>
            </div>
        </div>

        <div style = "margin: 40px 0 20px 20px;font-weight:bold;">Comment:</div>
        
        <div class = "userCommentHolder">
            <a href = "javascript:void(0)" style="text-decoration:none;">
                <img src="appContainer/images/gms/tft.jpg" alt="User" style="width:40px;margin: 0 0 0 20px;" class="rounded-pill"> 
            </a>
            <input type="text" placeholder="Add comment...">
            <button class="btn btn-primary addNewCmt" onclick = "addCmt(this)">Comment</button>
        </div>

        <div class = "comment">
            <a href = "javascript:void(0)" style="text-decoration:none;">
                <img src="appContainer/images/gms/tft.jpg" alt="User" style="width:40px;margin: 0 0 0 20px;" class="rounded-pill"> 
            </a>
            <div id = "chat">
                Hello
            </div>
            <button onclick = "dltCmt(this)" class="btn btn-primary deleteCmt">Delete</button>
        </div>

    </div>
</body>
</html>