<?php 
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>STAPPS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="./style/style.css">
  <script src="index1.js"></script>

</head>
<body style = "overflow-x:hidden;">
  <nav class="navbar navbar-expand-sm" style="box-shadow: 0px 1px 2px #ccc">
    <div class="container-fluid">
    <a class="navbar-brand" href="#">
        <img src="images/logo2.png" alt="Logo" style="width:100px;">
    </a>
    <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav me-auto">
        <li class="nav-item">
            <a class="nav-link" href="index.php">Box App</a>
        </li>
        </ul>

        <div class="searchBox">
            <span id="searchIcon"><i class="fa fa-search"></i></span>
            <input type="search" id="search" placeholder="Search..." />
        </div>

        <a class="nav-link" href="<?php
        if(!isset($_SESSION['userName'])){
            $_SESSION['currPage'] = 'index.php';
            echo 'loginForm.php'; 
        }
        else {
            echo 'admin/logout.php?currPage=index.php';
        }
        ?>">
        <?php
        if(!isset($_SESSION['userName']))
            echo 'Login';
        else {
            echo $_SESSION['userName'];
        }
        ?>
        </a>
        <a class="navbar-brand" href="./appManagerment.php" style = "margin-left:1%">
            <img src="images/defaultAvatar.png" id = "userImg" alt="User" style="width:40px;" class="rounded-pill"> 
        </a>
    </div>
    </div>
  </nav>
      
  <div class="container justify-content-center d-flex mt-3">
    <div class="body col-11">
      <div class="most-favodite-apps col-12 d-flex">
        <!-- ================================================================ -->
        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
          </div>
          <div class="carousel-inner">
            <div style="background-image: url('./images/tft.jpg');" class="carousel-item active">
            </div>
            <div style="background-image: url('./images/pubg.jpg');" class="carousel-item">
            </div>
            <div style="background-image: url('./images/fo4.jpg');" class="carousel-item">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>

      

        <div class="favorite-apps__list-apps">
          <p style = "font-weight: bold;">Game Hot 2022</p>

          <a href="#" class="favorite-apps__list-app">
            <div class="favorite-apps__list-app__image" style="background-image: url('./appContainer/images/gms/tft.jpg');"></div>
            <div class="favorite-apps__list-app__info">
              <span class="favorite-apps__list-apps__info__name">League of legends</span> <br>
              <span class="favorite-apps__list-apps__info__user-name">Riot</span>
            </div>
          </a>
          <a href="#" class="favorite-apps__list-app">
            <div class="favorite-apps__list-app__image" style="background-image: url('./appContainer/images/gms/tft.jpg');"></div>
            <div class="favorite-apps__list-app__info">
              <span class="favorite-apps__list-apps__info__name">League of legends</span> <br>
              <span class="favorite-apps__list-apps__info__user-name">Riot</span>
            </div>
          </a>
          <a href="#" class="favorite-apps__list-app">
            <div class="favorite-apps__list-app__image" style="background-image: url('./appContainer/images/gms/tft.jpg');"></div>
            <div class="favorite-apps__list-app__info">
              <span class="favorite-apps__list-apps__info__name">League of legends</span> <br>
              <span class="favorite-apps__list-apps__info__user-name">Riot</span>
            </div>
          </a>
          <a href="#" class="favorite-apps__list-app">
            <div class="favorite-apps__list-app__image" style="background-image: url('./appContainer/images/gms/tft.jpg');"></div>
            <div class="favorite-apps__list-app__info">
              <span class="favorite-apps__list-apps__info__name">League of legends</span> <br>
              <span class="favorite-apps__list-apps__info__user-name">Riot</span>
            </div>
          </a>
          <a href="#" class="favorite-apps__list-app">
            <div class="favorite-apps__list-app__image" style="background-image: url('./appContainer/images/gms/tft.jpg');"></div>
            <div class="favorite-apps__list-app__info">
              <span class="favorite-apps__list-apps__info__name">League of legends</span> <br>
              <span class="favorite-apps__list-apps__info__user-name">Riot</span>
            </div>
          </a>
        </div>
        
        
        
        
        
        
        <!-- ================================================================ -->
      </div>
      




      <div class="common-apps">
          <h4 class="common-apps__title">Ứng dụng tải nhiều</h4>
          <div class="row common-apps__apps-bar"> </div>
      </div>

      <div class="app-type p-2">
        <div class="app-type__games">
            <h4 class="app-type--title">
                Trò chơi
            </h4>
            <div id = "moreApps" class = "holder">
              <div id = "btnHolder">
                <button id = "moreBtn"> More </button>
                <button onclick ="scrollDiv(this,'right')" class = "fas rightarrow arrow" style = "margin-right: 20px;">&#xf105;</button>
                <button onclick ="scrollDiv(this,'left')" class = "fas leftarrow arrow" >&#xf104;</button>
              </div>
              <div id = "appBasket" class="appB">
                <?php
                  for($i = 0;$i <= 20;$i++){
                      echo "<a href='javascript:void(0)' class='app-type__game--containt app-containt col-4'>";
                      echo "<div class='game-containt__img img-color'></div>";
                      echo "<div class='infor'>";
                      echo "<div class='main-img'><img src='images/empty.png' width='56' height='56' border-radius='4'></image></div>";
                      echo "<div class='infor-text'>";
                      echo "<h5 class='game-containt__name'>Test 1</h5>";
                      echo "<span class='game-containt__username'>Test 2</span>";
                      echo "</div>";
                      echo "</div>";
                      echo "</a>";
                  }
                ?>
              </div>
            </div>
        </div>

        <div class="app-type__serviceapps">
              <h4 class="app-type--title">
                  Ứng dụng dịch vụ
              </h4>
              <div id = "moreApps" class = "holder">
                <div id = "btnHolder">
                  <button id = "moreBtn"> More </button>
                  <button onclick ="scrollDiv(this,'right')" class = "fas rightarrow arrow" style = "margin-right: 20px;">&#xf105;</button>
                  <button onclick ="scrollDiv(this,'left')" class = "fas leftarrow arrow" >&#xf104;</button>
                </div>
                <div id = "appBasket" class="appB">
                  <?php
                  for($i = 0;$i <= 20;$i++){
                      echo "<a href='javascript:void(0)' class='app-type__game--containt app-containt col-4'>";
                      echo "<div class='game-containt__img img-color'></div>";
                      echo "<div class='infor'>";
                      echo "<div class='main-img'><img src='images/empty.png' width='56' height='56' border-radius='4'></image></div>";
                      echo "<div class='infor-text'>";
                      echo "<h5 class='game-containt__name'>Test 1</h5>";
                      echo "<span class='game-containt__username'>Test 2</span>";
                      echo "</div>";
                      echo "</div>";
                      echo "</a>";
                  }
                  ?>
                </div>
              </div>

        </div>


        <div class="app-type__shoppingapps">
              <h4 class="app-type--title">
                  Ứng dụng mua sắm
              </h4>
              <div id = "moreApps" class = "holder">
                <div id = "btnHolder">
                  <button id = "moreBtn"> More </button>
                  <button onclick ="scrollDiv(this,'right')" class = "fas rightarrow arrow" style = "margin-right: 20px;">&#xf105;</button>
                  <button onclick ="scrollDiv(this,'left')" class = "fas leftarrow arrow" >&#xf104;</button>
                </div>
              <div id = "appBasket" class = "appB">
                <?php
                  for($i = 0;$i <= 20;$i++){
                      echo "<a href='javascript:void(0)' class='app-type__game--containt app-containt col-4'>";
                      echo "<div class='game-containt__img img-color'></div>";
                      echo "<div class='infor'>";
                      echo "<div class='main-img'><img src='images/empty.png' width='56' height='56' border-radius='4'></image></div>";
                      echo "<div class='infor-text'>";
                      echo "<h5 class='game-containt__name'>Test 1</h5>";
                      echo "<span class='game-containt__username'>Test 2</span>";
                      echo "</div>";
                      echo "</div>";
                      echo "</a>";
                  }
                ?>
              </div>
            </div>
          </div>

          <div class="app-type__socialnwapps">
              <h4 class="app-type--title">
                  Mạng xã hội
              </h4>
              <div id = "moreApps" class = "holder">
                <div id = "btnHolder">
                    <button id = "moreBtn"> More </button>
                    <button onclick ="scrollDiv(this,'right')" class = "fas rightarrow arrow" style = "margin-right: 20px;">&#xf105;</button>
                    <button onclick ="scrollDiv(this,'left')" class = "fas leftarrow arrow" >&#xf104;</button>
                </div>
                <div id = "appBasket" class = "appB">
                  <?php
                    for($i = 0;$i <= 20;$i++){
                        echo "<a href='javascript:void(0)' class='app-type__game--containt app-containt col-4'>";
                        echo "<div class='game-containt__img img-color'></div>";
                        echo "<div class='infor'>";
                        echo "<div class='main-img'><img src='images/empty.png' width='56' height='56' border-radius='4'></image></div>";
                        echo "<div class='infor-text'>";
                        echo "<h5 class='game-containt__name'>Test 1</h5>";
                        echo "<span class='game-containt__username'>Test 2</span>";
                        echo "</div>";
                        echo "</div>";
                        echo "</a>";
                    }
                  ?>
                </div>
            </div>
          </div>
        
      </div>
        
      </div>
    </div>
  </div>

  
  <script defer src="/handleLogic/index.js"></script>
  <script defer src="/handleLogic/search.js"></script>
      
</body>
</html>